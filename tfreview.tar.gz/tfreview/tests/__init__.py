"""
Test suite for TFReview.
"""